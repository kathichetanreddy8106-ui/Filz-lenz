/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // pdfjs-dist ships as ESM and is only ever imported dynamically from
  // client components (see lib/pdf.ts) — transpilePackages ensures Next's
  // build handles its module format correctly instead of relying on a
  // runtime CDN <script> tag.
  transpilePackages: ['pdfjs-dist'],
  webpack: (config) => {
    // pdfjs-dist optionally references the Node 'canvas' package for
    // server-side rendering of PDF pages, which this app never does (all
    // PDF parsing happens client-side, text-only). Aliasing it off avoids
    // a needless native-dependency build failure.
    config.resolve.alias.canvas = false;
    return config;
  },
};

export default nextConfig;
