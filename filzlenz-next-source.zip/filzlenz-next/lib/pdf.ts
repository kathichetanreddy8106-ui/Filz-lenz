import type { PageText } from '../types/analysis';
import { reconstructTextFromItems } from './pdfText';

/**
 * Extracts text page-by-page from a PDF File, entirely in the browser.
 *
 * pdfjs-dist is imported dynamically (not at module top-level) for two
 * reasons: it touches browser-only globals on load, and dynamic import
 * keeps it out of the server bundle so Next.js never tries to evaluate it
 * during server-side rendering. Call this only from client components
 * (see components/UploadZone.tsx, which is marked 'use client').
 *
 * The worker is resolved from the installed npm package via new URL(...),
 * which Next.js's webpack build packages alongside the app — no runtime
 * dependency on any CDN.
 */
interface PdfjsTextItem {
  str: string;
  hasEOL?: boolean;
}

export async function extractPdfPages(file: File): Promise<PageText[]> {
  if (typeof window === 'undefined') {
    throw new Error('extractPdfPages can only run in the browser.');
  }

  const pdfjsLib = await import('pdfjs-dist');
  // Vite/webpack-compatible worker URL resolution — bundled by Next's build,
  // not fetched from a CDN at runtime.
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url
  ).toString();

  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
  const pdf = await loadingTask.promise;

  const pages: PageText[] = [];
  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const content = await page.getTextContent();
    const items = content.items.filter((item): item is PdfjsTextItem => 'str' in item);
    const text = reconstructTextFromItems(items);
    pages.push({ pageNumber: pageNum, text });
  }
  return pages;
}
