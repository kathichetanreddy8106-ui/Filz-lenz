/**
 * pdf.js's getTextContent() returns text as a flat list of positioned runs
 * ("items"), not lines — joining item.str with a space (as an earlier
 * version of this code did) collapses an entire page into one line and
 * silently breaks every downstream feature that depends on line structure:
 * extractHeadings() and detectTables() both split on '\n'.
 *
 * pdf.js marks the end of each visual line with `hasEOL` on the text item.
 * This reconstructs real line breaks from that flag, so heading and table
 * detection see the document the way it's actually laid out.
 */
export interface PdfTextItemLike {
  str: string;
  hasEOL?: boolean;
}

export function reconstructTextFromItems(items: PdfTextItemLike[]): string {
  let out = '';
  for (const item of items) {
    out += item.str;
    out += item.hasEOL ? '\n' : ' ';
  }
  return out;
}
