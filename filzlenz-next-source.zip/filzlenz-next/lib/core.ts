/**
 * Filz Lenz — core.ts
 *
 * Deterministic, local, dependency-free text intelligence engine.
 * This is a direct TypeScript port of the original lib/core.js prototype
 * (verified with 19/19 passing tests). The algorithms are UNCHANGED —
 * only types, module structure, and minor readability tweaks were added.
 *
 * No network calls. No paid AI. No DOM dependency — safe to import from
 * both server and client code, and to unit test directly in Node.
 */

import type {
  LanguageInfo,
  HeadingInfo,
  TableBlock,
  ExtractedEntities,
  EntityCandidate,
  SummaryResult,
  QaIndex,
  QaVector,
  AskResult,
} from '../types/analysis';

// ---------- Stopwords (small, curated, per language) ----------
const STOPWORDS: Record<string, string[]> = {
  en: ['the','a','an','and','or','but','is','are','was','were','be','been','being','to','of','in','on','at','for','with','as','by','that','this','these','those','it','its','from','has','have','had','not','no','so','if','than','then','also','can','will','would','should','could','into','about','which','who','whom','their','they','we','you','i','he','she','him','her','his','our','your','there','here','all','any','more','most','such','only','other','some','what','when','where','why','how'],
  es: ['el','la','los','las','un','una','y','o','pero','es','son','fue','ser','de','en','a','para','con','como','por','que','este','esta','estos','esas','su','sus','desde','no','si','tambien','puede','sobre','cual','quien','ellos','nosotros'],
  fr: ['le','la','les','un','une','et','ou','mais','est','sont','etre','de','en','a','pour','avec','comme','par','que','ce','cette','ces','son','ses','depuis','non','si','aussi','peut','sur','quel','qui','ils','nous'],
  de: ['der','die','das','ein','eine','und','oder','aber','ist','sind','war','sein','zu','von','in','auf','fur','mit','als','durch','dass','dieser','diese','ihr','ihre','seit','nicht','auch','kann','uber','wer'],
  pt: ['o','a','os','as','um','uma','e','ou','mas','e','sao','foi','ser','de','em','para','com','como','por','que','este','esta','estes','essas','seu','sua','desde','nao','se','tambem','pode','sobre','quem','eles','nos'],
};

const LANGUAGE_NAMES: Record<string, string> = {
  en: 'English',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  pt: 'Portuguese',
};

const GENERIC_STOP = STOPWORDS.en; // used for scoring regardless of detected language (best-effort)

// ---------- Basic tokenization ----------
export function tokenizeWords(text: string): string[] {
  if (!text) return [];
  const matches = text.toLowerCase().match(/[a-zA-ZÀ-ÖØ-öø-ÿ']+/g);
  return matches || [];
}

export function countWords(text: string): number {
  return tokenizeWords(text).length;
}

export function countChars(text: string): number {
  return text ? text.length : 0;
}

export function countLines(text: string): number {
  if (!text) return 0;
  return text.split(/\r\n|\r|\n/).length;
}

export function estimateReadingTimeMinutes(wordCount: number): number {
  const WPM = 200;
  return Math.max(1, Math.round(wordCount / WPM));
}

// ---------- Sentence splitting ----------
export function splitSentences(text: string): string[] {
  if (!text) return [];
  const normalized = text.replace(/\s+/g, ' ').trim();
  if (!normalized) return [];
  // Split on sentence-ending punctuation followed by space + capital/number.
  const raw = normalized.split(/(?<=[.!?])\s+(?=[A-Z0-9"'\u201C])/);
  const sentences: string[] = [];
  for (const chunk of raw) {
    const s = chunk.trim();
    if (s.length > 0) sentences.push(s);
  }
  return sentences;
}

// ---------- Language detection (heuristic, stopword overlap) ----------
export function detectLanguage(text: string): LanguageInfo {
  const words = tokenizeWords(text);
  if (words.length < 20) return { language: 'Not detected', confidence: 0 };

  const counts: Record<string, number> = {};
  const langs = Object.keys(STOPWORDS);
  langs.forEach((l) => (counts[l] = 0));

  const sampled = words.slice(0, 2000);
  sampled.forEach((w) => {
    langs.forEach((l) => {
      if (STOPWORDS[l].indexOf(w) !== -1) counts[l]++;
    });
  });

  let best: string | null = null;
  let bestScore = 0;
  langs.forEach((l) => {
    const score = counts[l] / sampled.length;
    if (score > bestScore) {
      bestScore = score;
      best = l;
    }
  });

  if (!best || bestScore < 0.03) {
    return { language: 'Not detected', confidence: Math.round(bestScore * 100) };
  }
  return { language: LANGUAGE_NAMES[best], confidence: Math.round(bestScore * 100) };
}

// ---------- Heading / section detection ----------
export function extractHeadings(text: string): Omit<HeadingInfo, 'pageNumber'>[] {
  const lines = text.split(/\r\n|\r|\n/);
  const headings: Omit<HeadingInfo, 'pageNumber'>[] = [];
  const refPattern = /^(references|bibliography|works cited)\s*$/i;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    const mdMatch = line.match(/^(#{1,4})\s+(.*)/);
    const numMatch = line.match(/^(\d+(?:\.\d+){0,3})[.)]?\s+([A-Z][^.]{2,80})$/);
    const isAllCapsShort = /^[A-Z0-9][A-Z0-9 ,:'&-]{2,60}$/.test(line) && line.split(' ').length <= 8;
    const isTitleCaseShort = /^([A-Z][a-zA-Z0-9'&-]*\s?){1,8}$/.test(line) && line.length <= 70 && line.split(' ').length <= 8;
    const nextLineBlank = i + 1 >= lines.length || lines[i + 1].trim() === '';

    if (mdMatch) {
      headings.push({ text: mdMatch[2].trim(), lineIndex: i, level: mdMatch[1].length, kind: 'markdown' });
    } else if (numMatch) {
      headings.push({ text: numMatch[2].trim(), lineIndex: i, level: numMatch[1].split('.').length, kind: 'numbered' });
    } else if (refPattern.test(line)) {
      headings.push({ text: line, lineIndex: i, level: 1, kind: 'references' });
    } else if (isAllCapsShort && nextLineBlank && line.length <= 60) {
      headings.push({ text: line, lineIndex: i, level: 1, kind: 'allcaps' });
    } else if (isTitleCaseShort && nextLineBlank && line.split(' ').length >= 2) {
      headings.push({ text: line, lineIndex: i, level: 2, kind: 'titlecase' });
    }
  }
  return headings;
}

// ---------- Table detection (heuristic) ----------
export function detectTables(text: string): Omit<TableBlock, 'pageNumber'>[] {
  const lines = text.split(/\r\n|\r|\n/);
  const tables: Omit<TableBlock, 'pageNumber'>[] = [];
  let i = 0;

  function columnsOf(line: string): string[] | null {
    if (line.indexOf('|') !== -1) {
      return line.split('|').map((c) => c.trim()).filter(Boolean);
    }
    if (/\t/.test(line)) {
      return line.split(/\t+/).map((c) => c.trim()).filter(Boolean);
    }
    if (/ {2,}/.test(line.trim())) {
      return line.trim().split(/ {2,}/).map((c) => c.trim()).filter(Boolean);
    }
    return null;
  }

  while (i < lines.length) {
    const cols = columnsOf(lines[i]);
    if (cols && cols.length >= 2) {
      const start = i;
      const colCount = cols.length;
      const rows: string[][] = [];
      let rowCount = 0;
      while (i < lines.length) {
        const c2 = columnsOf(lines[i]);
        if (c2 && c2.length >= 2 && Math.abs(c2.length - colCount) <= 1) {
          rows.push(c2);
          rowCount++;
          i++;
        } else break;
      }
      if (rowCount >= 2) {
        tables.push({ startLine: start, endLine: i - 1, rowCount, columnCount: colCount, rows: rows.slice(0, 50) });
      } else {
        i = start + 1;
      }
    } else {
      i++;
    }
  }
  return tables;
}

// ---------- Entity extraction ----------
function uniq(arr: string[]): string[] {
  const seen: Record<string, boolean> = {};
  const out: string[] = [];
  for (const raw of arr) {
    const v = raw.trim();
    if (!seen[v]) {
      seen[v] = true;
      out.push(v);
    }
  }
  return out;
}

export function extractEntities(text: string): ExtractedEntities {
  const emails = uniq(text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || []);
  const urls = uniq(text.match(/\bhttps?:\/\/[^\s)>\]]+/g) || []);
  const phones = uniq(
    (text.match(/(?:\+?\d{1,3}[-.\s]?)?(?:\(\d{2,4}\)[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}(?:[-.\s]?\d{2,4})?/g) || []).filter((p) => {
      const d = p.replace(/\D/g, '');
      return d.length >= 7 && d.length <= 13;
    })
  );
  const dates = uniq(
    text.match(
      /\b(?:\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4}|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?,?\s+\d{4})\b/gi
    ) || []
  );
  const money = uniq(
    text.match(/(?:[$€£₹¥]\s?\d[\d,]*(?:\.\d+)?(?:\s?(?:million|billion|k|m|bn))?|\b\d[\d,]*(?:\.\d+)?\s?(?:USD|EUR|GBP|INR|Rs\.?|dollars|rupees|euros))/gi) || []
  );
  const percentages = uniq(text.match(/\b\d{1,3}(?:\.\d+)?\s?%/g) || []);
  const numbers = uniq((text.match(/\b\d{2,}(?:,\d{3})*(?:\.\d+)?\b/g) || []).slice(0, 200));

  // Heuristic candidate names/orgs: sequences of 2-4 capitalized words.
  // Explicitly NOT true named-entity recognition — labeled as such in the UI.
  const candidateRegex = /\b([A-Z][a-zA-Z'&.-]+(?:\s+[A-Z][a-zA-Z'&.-]+){1,3})\b/g;
  const raw = text.match(candidateRegex) || [];
  const freq: Record<string, number> = {};
  raw.forEach((name) => {
    const clean = name.trim();
    if (clean.split(' ').length < 2) return;
    freq[clean] = (freq[clean] || 0) + 1;
  });
  const nameOrgCandidates: EntityCandidate[] = Object.keys(freq)
    .sort((a, b) => freq[b] - freq[a])
    .slice(0, 25)
    .map((name) => ({ text: name, occurrences: freq[name] }));

  return { emails, urls, phones, dates, money, percentages, numbers, nameOrgCandidates };
}

// ---------- Frequency-based extractive summarization ----------
export function wordFrequencies(text: string): Record<string, number> {
  const words = tokenizeWords(text);
  const freq: Record<string, number> = {};
  words.forEach((w) => {
    if (GENERIC_STOP.indexOf(w) !== -1) return;
    if (w.length < 3) return;
    freq[w] = (freq[w] || 0) + 1;
  });
  let max = 0;
  Object.keys(freq).forEach((k) => {
    if (freq[k] > max) max = freq[k];
  });
  if (max > 0) Object.keys(freq).forEach((k) => (freq[k] = freq[k] / max));
  return freq;
}

interface ScoredSentence {
  index: number;
  text: string;
  score: number;
  wordCount: number;
}

function scoreSentences(sentences: string[], freq: Record<string, number>): ScoredSentence[] {
  return sentences.map((s, idx) => {
    const words = tokenizeWords(s);
    let score = 0;
    words.forEach((w) => (score += freq[w] || 0));
    const normalized = words.length > 0 ? score / Math.sqrt(words.length) : 0;
    return { index: idx, text: s, score: normalized, wordCount: words.length };
  });
}

export function summarize(text: string): SummaryResult {
  const sentences = splitSentences(text);
  if (sentences.length === 0) {
    return { oneSentence: '', short: '', extended: '', sentenceCount: 0 };
  }
  const freq = wordFrequencies(text);
  const scored = scoreSentences(sentences, freq);
  const ranked = [...scored].sort((a, b) => b.score - a.score);

  function topInOrder(n: number): string {
    return ranked
      .slice(0, Math.min(n, ranked.length))
      .sort((a, b) => a.index - b.index)
      .map((s) => s.text)
      .join(' ');
  }

  const shortCount = Math.max(2, Math.min(4, Math.ceil(sentences.length * 0.1)));
  const extCount = Math.max(shortCount + 3, Math.min(15, Math.ceil(sentences.length * 0.25)));

  return {
    oneSentence: topInOrder(1),
    short: topInOrder(shortCount),
    extended: topInOrder(extCount),
    sentenceCount: sentences.length,
  };
}

// ---------- Local retrieval (TF-IDF-ish) for Ask-the-file ----------
export function buildIndex(sentences: string[]): QaIndex {
  const docs = sentences.map((s) => tokenizeWords(s));
  const df: Record<string, number> = {};
  docs.forEach((tokens) => {
    const seen: Record<string, boolean> = {};
    tokens.forEach((t) => {
      if (GENERIC_STOP.indexOf(t) !== -1) return;
      if (!seen[t]) {
        seen[t] = true;
        df[t] = (df[t] || 0) + 1;
      }
    });
  });
  const N = docs.length || 1;
  const idf: Record<string, number> = {};
  Object.keys(df).forEach((t) => {
    idf[t] = Math.log((N + 1) / (df[t] + 1)) + 1;
  });
  const vectors: QaVector[] = docs.map((tokens) => {
    const tf: Record<string, number> = {};
    tokens.forEach((t) => {
      if (GENERIC_STOP.indexOf(t) !== -1) return;
      tf[t] = (tf[t] || 0) + 1;
    });
    const vec: QaVector = {};
    Object.keys(tf).forEach((t) => (vec[t] = tf[t] * (idf[t] || 1)));
    return vec;
  });
  return { idf, vectors, sentences };
}

function vectorNorm(vec: QaVector): number {
  let sum = 0;
  Object.keys(vec).forEach((k) => (sum += vec[k] * vec[k]));
  return Math.sqrt(sum) || 1;
}

export interface AskOptions {
  threshold?: number;
  topK?: number;
}

export function askQuestion(index: QaIndex, question: string, options: AskOptions = {}): AskResult {
  const threshold = options.threshold ?? 0.12;
  const topK = options.topK ?? 3;

  const qTokens = tokenizeWords(question).filter((t) => GENERIC_STOP.indexOf(t) === -1);
  if (qTokens.length === 0) {
    return { answered: false, results: [], reason: 'The question did not contain any searchable terms.' };
  }

  const qVec: QaVector = {};
  qTokens.forEach((t) => (qVec[t] = (qVec[t] || 0) + (index.idf[t] || 1)));
  const qNorm = vectorNorm(qVec);

  const scored = index.vectors.map((vec, i) => {
    let dot = 0;
    Object.keys(qVec).forEach((t) => {
      if (vec[t]) dot += qVec[t] * vec[t];
    });
    const sNorm = vectorNorm(vec);
    const cosine = dot / (qNorm * sNorm);
    return { index: i, score: cosine, text: index.sentences[i] };
  });

  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, topK).filter((s) => s.score > 0);

  if (top.length === 0 || top[0].score < threshold) {
    return { answered: false, results: top, reason: "I couldn't find a reliable answer in this file." };
  }
  return { answered: true, results: top };
}
