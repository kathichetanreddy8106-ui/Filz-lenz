/**
 * Filz Lenz — utils/exportPayloads.ts tests
 * Run with: npx tsx tests/exportPayloads.test.ts
 */
import assert from 'node:assert';
import { analyzePages } from '../services/analysisService';
import { buildJsonExport, buildTxtExport, buildMarkdownExport, buildTableCsv, buildTableJson } from '../utils/exportPayloads';

let pass = 0;
let fail = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    pass++;
    console.log('  ok   - ' + name);
  } catch (e) {
    fail++;
    console.log('  FAIL - ' + name);
    console.log('         ' + (e as Error).message);
  }
}

console.log('\nFilz Lenz exportPayloads.ts — test run\n');

const sample = analyzePages(
  'contract.pdf',
  4096,
  [{ pageNumber: 1, text: 'Agreement\n\nThis agreement is dated 5 May 2023 and involves $10,000. Contact legal@example.com.' }],
  true,
  1
);

test('buildJsonExport produces valid, parseable JSON with expected fields', () => {
  const json = buildJsonExport(sample);
  const parsed = JSON.parse(json);
  assert.strictEqual(parsed.fileName, 'contract.pdf');
  assert.ok(Array.isArray(parsed.headings));
  assert.ok(parsed.entities.emails.includes('legal@example.com'));
});

test('buildTxtExport includes file name, stats, and detected entities', () => {
  const txt = buildTxtExport(sample);
  assert.ok(txt.includes('contract.pdf'));
  assert.ok(txt.includes('legal@example.com'));
  assert.ok(txt.includes('$10,000') || txt.toLowerCase().includes('money'));
});

test('buildMarkdownExport produces a markdown document with a title and entity section', () => {
  const md = buildMarkdownExport(sample);
  assert.ok(md.startsWith('# Filz Lenz analysis'));
  assert.ok(md.includes('## Entities'));
});

test('buildTableCsv correctly escapes embedded quotes and commas', () => {
  const table = { startLine: 0, endLine: 1, rowCount: 2, columnCount: 2, pageNumber: 1, rows: [['Name', 'Note'], ['Jane "JJ" Doe', 'Has, a comma']] };
  const csv = buildTableCsv(table);
  assert.ok(csv.includes('"Jane ""JJ"" Doe"'));
  assert.ok(csv.includes('"Has, a comma"'));
});

test('buildTableJson round-trips the row data exactly', () => {
  const table = { startLine: 0, endLine: 1, rowCount: 1, columnCount: 2, pageNumber: null, rows: [['a', 'b']] };
  const parsed = JSON.parse(buildTableJson(table));
  assert.deepStrictEqual(parsed, [['a', 'b']]);
});

test('export builders never throw on a document with no detected entities/tables/headings', () => {
  const empty = analyzePages('plain.txt', 20, [{ pageNumber: null, text: 'Just plain words here with nothing special at all.' }], false, null);
  assert.doesNotThrow(() => buildJsonExport(empty));
  assert.doesNotThrow(() => buildTxtExport(empty));
  assert.doesNotThrow(() => buildMarkdownExport(empty));
});

console.log('\n' + pass + ' passed, ' + fail + ' failed\n');
if (fail > 0) process.exit(1);
