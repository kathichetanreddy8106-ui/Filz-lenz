/**
 * Filz Lenz — lib/core.ts unit tests
 * Run with: npx tsx tests/core.test.ts
 *
 * Deliberately framework-free (uses Node's built-in `assert`) so tests run
 * without any npm install — consistent with the original prototype's test
 * approach. Once the team adds Jest/Vitest for the wider app, these ports
 * 1:1 into `describe`/`it` blocks; the assertions themselves don't need to
 * change.
 *
 * The first 19 tests are a direct port of the original prototype's
 * test/core.test.js (same fixtures, same assertions) to confirm the
 * migration introduced no regression. Tests after that comment marker are
 * new coverage requested for productionization.
 */
import assert from 'node:assert';
import * as Core from '../lib/core';

let pass = 0;
let fail = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    pass++;
    console.log('  ok   - ' + name);
  } catch (e) {
    fail++;
    console.log('  FAIL - ' + name);
    console.log('         ' + (e as Error).message);
  }
}

// ---------- Synthetic fixtures ----------
const RESEARCH_PAPER =
  'Title: A Study of Local Retrieval Methods\n\n' +
  'Abstract\n\n' +
  'This paper presents a deterministic method for local document retrieval. ' +
  'The method does not depend on any paid API. It was evaluated on synthetic data.\n\n' +
  '1. Introduction\n\n' +
  'Document intelligence tools increasingly rely on cloud inference. ' +
  'This work explores an alternative that runs entirely inside the browser. ' +
  'Contact the authors at research.team@example.com for details.\n\n' +
  '2. Methodology\n\n' +
  'We used a TF-IDF style ranking approach. The dataset contained 1200 sentences. ' +
  'Processing was completed on 15 March 2024. The total budget was $0.\n\n' +
  '3. Results\n\n' +
  'Accuracy improved by 23% over the baseline. The p-value was below 0.05.\n\n' +
  'References\n\n' +
  '[1] Smith, J. Local Retrieval Systems. 2020.\n' +
  '[2] Doe, A. Deterministic NLP. 2019.\n';

const RESUME_TEXT =
  'Jane Carter\n' +
  'jane.carter@email.com | +1 415 555 0134\n\n' +
  'Experience\n\n' +
  'Senior Engineer at Acme Corporation, 2019-2024. Led a team building data pipelines.\n\n' +
  'Education\n\n' +
  'B.S. Computer Science, State University, 2015.\n';

const TABLE_TEXT = 'Product      Price     Qty\n' + 'Widget A     $10.00    5\n' + 'Widget B     $25.50    2\n' + 'Widget C     $7.25     12\n';

console.log('\nFilz Lenz core.ts — test run\n');

// ================= Ported from the original prototype (regression check) =================

test('countWords counts words correctly', () => {
  assert.strictEqual(Core.countWords('one two three'), 3);
  assert.strictEqual(Core.countWords(''), 0);
});

test('countChars and countLines are correct', () => {
  assert.strictEqual(Core.countChars('abc'), 3);
  assert.strictEqual(Core.countLines('a\nb\nc'), 3);
});

test('estimateReadingTimeMinutes scales with word count and has a floor of 1', () => {
  assert.strictEqual(Core.estimateReadingTimeMinutes(0), 1);
  assert.strictEqual(Core.estimateReadingTimeMinutes(400), 2);
});

test('splitSentences splits the research paper into multiple sentences', () => {
  const sentences = Core.splitSentences(RESEARCH_PAPER);
  assert.ok(sentences.length > 5, 'expected more than 5 sentences, got ' + sentences.length);
});

test('detectLanguage identifies English text with reasonable confidence', () => {
  const result = Core.detectLanguage(RESEARCH_PAPER + RESEARCH_PAPER);
  assert.strictEqual(result.language, 'English');
  assert.ok(result.confidence > 0);
});

test('detectLanguage returns "Not detected" for very short input', () => {
  const result = Core.detectLanguage('hi');
  assert.strictEqual(result.language, 'Not detected');
});

test('extractHeadings finds numbered section headings', () => {
  const headings = Core.extractHeadings(RESEARCH_PAPER);
  const texts = headings.map((h) => h.text);
  assert.ok(texts.indexOf('Introduction') !== -1, 'expected Introduction, got: ' + JSON.stringify(texts));
  assert.ok(texts.indexOf('Methodology') !== -1, 'expected Methodology');
});

test('extractHeadings finds the References section', () => {
  const headings = Core.extractHeadings(RESEARCH_PAPER);
  const refHeading = headings.filter((h) => h.kind === 'references');
  assert.ok(refHeading.length >= 1, 'expected a references heading to be detected');
});

test('extractEntities finds the email address', () => {
  const entities = Core.extractEntities(RESEARCH_PAPER);
  assert.ok(entities.emails.indexOf('research.team@example.com') !== -1);
});

test('extractEntities finds the phone number in the resume', () => {
  const entities = Core.extractEntities(RESUME_TEXT);
  assert.ok(entities.phones.length >= 1, 'expected a phone number, got: ' + JSON.stringify(entities.phones));
});

test('extractEntities finds a percentage and a currency value', () => {
  const entities = Core.extractEntities(RESEARCH_PAPER);
  assert.ok(entities.percentages.some((p) => p.indexOf('23') !== -1), 'expected 23% to be detected');
  assert.ok(entities.money.some((m) => m.indexOf('0') !== -1), 'expected $0 to be detected');
});

test('extractEntities finds a date', () => {
  const entities = Core.extractEntities(RESEARCH_PAPER);
  assert.ok(entities.dates.length >= 1, 'expected at least one date, got: ' + JSON.stringify(entities.dates));
});

test('extractEntities never crashes and returns empty arrays for a doc with no entities', () => {
  const entities = Core.extractEntities('just some plain words with nothing special in them at all');
  assert.strictEqual(entities.emails.length, 0);
  assert.strictEqual(entities.money.length, 0);
});

test('detectTables identifies the aligned table', () => {
  const tables = Core.detectTables(TABLE_TEXT);
  assert.ok(tables.length >= 1, 'expected at least one table');
  assert.ok(tables[0].rowCount >= 2);
});

test('summarize returns non-empty one-sentence, short, and extended summaries', () => {
  const summary = Core.summarize(RESEARCH_PAPER);
  assert.ok(summary.oneSentence.length > 0);
  assert.ok(summary.short.length >= summary.oneSentence.length);
  assert.ok(summary.extended.length >= summary.short.length);
  assert.ok(summary.sentenceCount > 0);
});

test('summarize on empty text returns empty strings without throwing', () => {
  const summary = Core.summarize('');
  assert.strictEqual(summary.oneSentence, '');
  assert.strictEqual(summary.sentenceCount, 0);
});

test('buildIndex + askQuestion retrieves the sentence about methodology', () => {
  const sentences = Core.splitSentences(RESEARCH_PAPER);
  const index = Core.buildIndex(sentences);
  const result = Core.askQuestion(index, 'What ranking approach was used?');
  assert.strictEqual(result.answered, true);
  assert.ok(
    result.results[0].text.toLowerCase().indexOf('tf-idf') !== -1,
    'expected top result to mention TF-IDF, got: ' + result.results[0].text
  );
});

test('askQuestion returns answered:false for a question with no relevant content', () => {
  const sentences = Core.splitSentences(RESEARCH_PAPER);
  const index = Core.buildIndex(sentences);
  const result = Core.askQuestion(index, 'What is the airspeed velocity of an unladen swallow?');
  assert.strictEqual(result.answered, false);
  assert.ok((result.reason ?? '').length > 0);
});

test('askQuestion never hallucinates: with an empty index it safely reports no answer', () => {
  const index = Core.buildIndex([]);
  const result = Core.askQuestion(index, 'anything at all');
  assert.strictEqual(result.answered, false);
});

// ================= New coverage added for productionization =================

test('[new] malformed input: null-ish/garbage strings never throw', () => {
  // @ts-expect-error deliberately passing wrong types to prove runtime safety
  assert.doesNotThrow(() => Core.countWords(undefined));
  assert.doesNotThrow(() => Core.splitSentences('   \n\n\t   '));
  assert.doesNotThrow(() => Core.extractHeadings(''));
  assert.doesNotThrow(() => Core.detectTables(''));
  assert.doesNotThrow(() => Core.extractEntities(''));
});

test('[new] empty document: every function degrades gracefully instead of guessing', () => {
  assert.strictEqual(Core.countWords(''), 0);
  assert.strictEqual(Core.splitSentences('').length, 0);
  assert.strictEqual(Core.extractHeadings('').length, 0);
  assert.strictEqual(Core.detectTables('').length, 0);
  assert.strictEqual(Core.detectLanguage('').language, 'Not detected');
  const idx = Core.buildIndex([]);
  assert.strictEqual(Core.askQuestion(idx, 'anything').answered, false);
});

test('[new] unusual Unicode: accented, CJK, and emoji text does not crash extraction', () => {
  const text = 'Café résumé naïve 北京市 東京都 🚀 emoji test with a date 5 May 2023 and email a@b.co';
  assert.doesNotThrow(() => Core.extractEntities(text));
  const entities = Core.extractEntities(text);
  assert.ok(entities.emails.includes('a@b.co'));
  // Word tokenization is Latin-script-oriented by design (documented
  // limitation) — it should still not throw or corrupt on CJK/emoji input.
  assert.ok(Core.countWords(text) > 0);
});

test('[new] large text: a ~50,000-word document is summarized and indexed without throwing', () => {
  const sentence = 'The quarterly report shows steady growth across every division of the company. ';
  const big = sentence.repeat(6000); // ~54,000 words
  const start = Date.now();
  const summary = Core.summarize(big);
  const sentences = Core.splitSentences(big);
  const index = Core.buildIndex(sentences);
  const result = Core.askQuestion(index, 'What does the report show?');
  const elapsedMs = Date.now() - start;
  assert.ok(summary.oneSentence.length > 0);
  assert.ok(result.answered);
  assert.ok(elapsedMs < 15000, `expected large-doc processing under 15s, took ${elapsedMs}ms`);
});

test('[new] duplicate entities are de-duplicated, not repeated', () => {
  const text = 'Email a@b.com again a@b.com and once more a@b.com. Visit https://x.com and https://x.com again.';
  const entities = Core.extractEntities(text);
  assert.strictEqual(entities.emails.filter((e) => e === 'a@b.com').length, 1);
  assert.strictEqual(entities.urls.filter((u) => u === 'https://x.com').length, 1);
});

test('[new] duplicate name/org candidates are counted, not listed multiple times', () => {
  const text = 'Acme Corporation announced results. Acme Corporation later confirmed the results. Acme Corporation is based in Ohio.';
  const entities = Core.extractEntities(text);
  const acme = entities.nameOrgCandidates.find((c) => c.text === 'Acme Corporation');
  assert.ok(acme, 'expected Acme Corporation to be a candidate');
  assert.strictEqual(acme!.occurrences, 3);
  assert.strictEqual(entities.nameOrgCandidates.filter((c) => c.text === 'Acme Corporation').length, 1);
});

test('[new] no-answer questions are refused rather than answered with a weak match', () => {
  const sentences = Core.splitSentences(RESUME_TEXT);
  const index = Core.buildIndex(sentences);
  const result = Core.askQuestion(index, 'What is the capital of Mongolia?');
  assert.strictEqual(result.answered, false);
  assert.strictEqual(result.reason, "I couldn't find a reliable answer in this file.");
});

console.log('\n' + pass + ' passed, ' + fail + ' failed\n');
if (fail > 0) process.exit(1);
