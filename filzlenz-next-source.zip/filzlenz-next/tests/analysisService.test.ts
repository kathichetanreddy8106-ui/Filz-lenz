/**
 * Filz Lenz — services/analysisService.ts tests
 * Run with: npx tsx tests/analysisService.test.ts
 */
import assert from 'node:assert';
import {
  validateFile,
  analyzePages,
  MAX_FILE_BYTES,
  UnsupportedFileError,
  EmptyContentError,
  FileTooLargeError,
} from '../services/analysisService';

let pass = 0;
let fail = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    pass++;
    console.log('  ok   - ' + name);
  } catch (e) {
    fail++;
    console.log('  FAIL - ' + name);
    console.log('         ' + (e as Error).message);
  }
}

function makeFile(name: string, content: string, type = 'text/plain'): File {
  return new File([content], name, { type });
}

console.log('\nFilz Lenz analysisService.ts — test run\n');

test('validateFile rejects unsupported file types with a clear message', () => {
  const f = makeFile('photo.png', 'binary-ish', 'image/png');
  assert.throws(() => validateFile(f), UnsupportedFileError);
});

test('validateFile rejects empty (0-byte) files', () => {
  const f = makeFile('empty.txt', '', 'text/plain');
  assert.throws(() => validateFile(f), EmptyContentError);
});

test('validateFile rejects files over the size limit', () => {
  const big = 'x'.repeat(1000);
  const f = new File([big], 'big.txt', { type: 'text/plain' });
  Object.defineProperty(f, 'size', { value: MAX_FILE_BYTES + 1 });
  assert.throws(() => validateFile(f), FileTooLargeError);
});

test('validateFile accepts .pdf and .txt', () => {
  const pdf = makeFile('doc.pdf', 'not a real pdf but has content', 'application/pdf');
  const txt = makeFile('doc.txt', 'hello world', 'text/plain');
  assert.deepStrictEqual(validateFile(pdf), { isPdf: true, isTxt: false });
  assert.deepStrictEqual(validateFile(txt), { isPdf: false, isTxt: true });
});

test('analyzePages throws EmptyContentError for a PDF with no extractable text (scanned PDF case)', () => {
  const pages = [
    { pageNumber: 1, text: '' },
    { pageNumber: 2, text: '   ' },
  ];
  assert.throws(() => analyzePages('scan.pdf', 1024, pages, true, 2), EmptyContentError);
});

test('analyzePages maps sentences to the correct page number for citations', () => {
  const pages = [
    { pageNumber: 1, text: 'Introduction\n\nThis is page one content about apples.' },
    { pageNumber: 2, text: 'Methodology\n\nThis is page two content about oranges and bananas.' },
  ];
  const result = analyzePages('doc.pdf', 2048, pages, true, 2);
  const orangeSentence = result.sentenceRecords.find((r) => r.text.toLowerCase().includes('oranges'));
  const appleSentence = result.sentenceRecords.find((r) => r.text.toLowerCase().includes('apples'));
  assert.ok(orangeSentence, 'expected a sentence mentioning oranges');
  assert.ok(appleSentence, 'expected a sentence mentioning apples');
  assert.strictEqual(orangeSentence!.pageNumber, 2);
  assert.strictEqual(appleSentence!.pageNumber, 1);
});

test('analyzePages associates the nearest preceding heading with each page\'s sentences', () => {
  // Note: the heading heuristic (unchanged from the original engine) only
  // matches multi-word title-case lines — a lone word like "Methodology"
  // is intentionally not treated as a heading to avoid false positives.
  const pages = [{ pageNumber: 1, text: 'Study Methodology\n\nWe used a survey of 500 participants.' }];
  const result = analyzePages('doc.pdf', 512, pages, true, 1);
  const target = result.sentenceRecords.find((r) => r.text.includes('survey'));
  assert.ok(target);
  assert.strictEqual(target!.heading, 'Study Methodology');
});

test('analyzePages on a .txt file has no page numbers (pageNumber is null throughout)', () => {
  const result = analyzePages('notes.txt', 100, [{ pageNumber: null, text: 'Just some plain notes about a meeting.' }], false, null);
  assert.strictEqual(result.stats.pageCount, null);
  result.sentenceRecords.forEach((r) => assert.strictEqual(r.pageNumber, null));
});

test('analyzePages computes stats consistent with the input text', () => {
  const text = 'One two three. Four five six seven.';
  const result = analyzePages('t.txt', 40, [{ pageNumber: null, text }], false, null);
  assert.strictEqual(result.stats.wordCount, 7);
  assert.ok(result.stats.charCount >= text.length - 1);
});

test('[regression] each sentence is attributed to its nearest preceding heading, not the whole page\'s first heading', () => {
  // A .txt file is always exactly one "page". The old logic attributed
  // every sentence on a page to that page's *first* heading, so a
  // multi-section .txt document had every citation point at section one.
  const text =
    'Executive Summary\n\n' +
    'Revenue grew steadily this quarter.\n\n' +
    'Key Metrics\n\n' +
    'Revenue increased by 18 percent compared to last quarter.\n\n' +
    'Conclusion\n\n' +
    'Growth is expected to continue into next year.\n';
  const result = analyzePages('report.txt', 500, [{ pageNumber: null, text }], false, null);

  const metricsSentence = result.sentenceRecords.find((r) => r.text.includes('18 percent'));
  const summarySentence = result.sentenceRecords.find((r) => r.text.includes('grew steadily'));

  assert.ok(metricsSentence, 'expected to find the "18 percent" sentence');
  assert.ok(summarySentence, 'expected to find the "grew steadily" sentence');
  assert.strictEqual(metricsSentence!.heading, 'Key Metrics', 'expected the metrics sentence to cite "Key Metrics", not the document\'s first heading');
  assert.strictEqual(summarySentence!.heading, 'Executive Summary');
});

console.log('\n' + pass + ' passed, ' + fail + ' failed\n');
if (fail > 0) process.exit(1);
