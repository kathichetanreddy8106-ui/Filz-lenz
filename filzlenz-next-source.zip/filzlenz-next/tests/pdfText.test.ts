/**
 * Filz Lenz — lib/pdfText.ts tests
 * Run with: npx tsx tests/pdfText.test.ts
 *
 * Regression test for a real bug found during the stabilization pass:
 * pdf.js text items were being joined with a bare space, collapsing every
 * page into a single line and silently breaking extractHeadings() and
 * detectTables() (both of which split on '\n') for every real PDF.
 */
import assert from 'node:assert';
import { reconstructTextFromItems } from '../lib/pdfText';
import { extractHeadings, detectTables } from '../lib/core';

let pass = 0;
let fail = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    pass++;
    console.log('  ok   - ' + name);
  } catch (e) {
    fail++;
    console.log('  FAIL - ' + name);
    console.log('         ' + (e as Error).message);
  }
}

console.log('\nFilz Lenz pdfText.ts — test run\n');

test('reconstructTextFromItems inserts a newline after items marked hasEOL', () => {
  const items = [
    { str: 'Introduction', hasEOL: true },
    { str: 'This is body text.', hasEOL: true },
    { str: 'Methodology', hasEOL: true },
    { str: 'More body text.', hasEOL: false },
  ];
  const text = reconstructTextFromItems(items);
  assert.strictEqual(text, 'Introduction\nThis is body text.\nMethodology\nMore body text. ');
});

test('reconstructTextFromItems with no EOL flags falls back to space-joined text (old behavior, still safe)', () => {
  const items = [{ str: 'a' }, { str: 'b' }, { str: 'c' }];
  assert.strictEqual(reconstructTextFromItems(items), 'a b c ');
});

test('reconstructTextFromItems on an empty item list returns an empty string', () => {
  assert.strictEqual(reconstructTextFromItems([]), '');
});

test('[regression] heading detection finds headings in reconstructed PDF text (was broken by space-joining)', () => {
  // Mirrors the real text-item shape pdf.js returned for a synthetic test
  // PDF generated during this stabilization pass. Numbered headings are
  // used because extractHeadings()'s title-case heuristic intentionally
  // requires 2+ words to avoid false positives on random capitalized
  // words — a pre-existing, documented limitation, not what this test is
  // checking. What this test checks is line-break reconstruction.
  const items = [
    { str: '1. Introduction', hasEOL: true },
    { str: 'This document is a synthetic test file for Filz Lenz.', hasEOL: true },
    { str: 'It was created on 5 May 2023 and involves a budget of $10,000.', hasEOL: true },
    { str: 'Contact the team at test.contact@example.com for questions.', hasEOL: true },
    { str: '2. Methodology', hasEOL: true },
    { str: 'We surveyed 250 participants and found a 42% improvement rate.', hasEOL: true },
    { str: 'Processing was completed successfully with zero errors.', hasEOL: false },
  ];
  const text = reconstructTextFromItems(items);
  const headings = extractHeadings(text).map((h) => h.text);

  assert.ok(headings.includes('Introduction'), 'expected "Introduction" to be detected as a heading, got: ' + JSON.stringify(headings));
  assert.ok(headings.includes('Methodology'), 'expected "Methodology" to be detected as a heading, got: ' + JSON.stringify(headings));

  // Prove the OLD (buggy) behavior really did fail this same assertion,
  // so this test is meaningfully checking the fix rather than something
  // that always passed.
  const naiveJoin = items.map((i) => i.str).join(' ');
  const naiveHeadings = extractHeadings(naiveJoin).map((h) => h.text);
  assert.strictEqual(naiveHeadings.length, 0, 'expected the old space-joined text to detect zero headings (confirming the bug existed)');
});

test('[regression] table detection can find aligned rows once real newlines are present', () => {
  const items = [
    { str: 'Product      Price     Qty', hasEOL: true },
    { str: 'Widget A     $10.00    5', hasEOL: true },
    { str: 'Widget B     $25.50    2', hasEOL: false },
  ];
  const text = reconstructTextFromItems(items);
  const tables = detectTables(text);
  assert.ok(tables.length >= 1, 'expected at least one table to be detected once line breaks are reconstructed');
});

console.log('\n' + pass + ' passed, ' + fail + ' failed\n');
if (fail > 0) process.exit(1);
