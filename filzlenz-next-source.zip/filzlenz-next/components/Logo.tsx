export function LogoMark({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="flGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#3b7cf6" />
          <stop offset="55%" stopColor="#34d3e8" />
          <stop offset="100%" stopColor="#9061f9" />
        </linearGradient>
      </defs>
      <path
        d="M14 10 C14 6.7 16.7 4 20 4 H38 L52 18 V50 C52 55.5 47.5 60 42 60 H20 C16.7 60 14 57.3 14 54 Z"
        fill="url(#flGrad)"
      />
      <path d="M38 4 L52 18 H42 C39.8 18 38 16.2 38 14 Z" fill="#fff" opacity="0.55" />
      <circle cx="41" cy="42" r="10" fill="none" stroke="#04060d" strokeWidth="4" />
      <circle cx="41" cy="42" r="10" fill="none" stroke="#eef1fb" strokeWidth="1.5" />
      <circle cx="38" cy="39" r="2.4" fill="#eef1fb" />
      <rect x="22" y="26" width="12" height="4" rx="2" fill="#04060d" opacity="0.5" />
      <rect x="22" y="34" width="9" height="4" rx="2" fill="#04060d" opacity="0.5" />
    </svg>
  );
}

export function Wordmark() {
  return (
    <span className="font-display font-bold text-lg tracking-tight">
      <span className="text-ink">Filz</span>
      <span className="bg-brand-gradient bg-clip-text text-transparent"> Lenz</span>
    </span>
  );
}
