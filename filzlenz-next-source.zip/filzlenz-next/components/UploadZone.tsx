'use client';

import { useCallback, useRef, useState } from 'react';
import type { DragEvent } from 'react';

interface UploadZoneProps {
  onFileSelected: (file: File) => void;
  maxBytes: number;
}

export function UploadZone({ onFileSelected, maxBytes }: UploadZoneProps) {
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const openPicker = useCallback(() => inputRef.current?.click(), []);

  const handleDrop = useCallback(
    (e: DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files?.[0];
      if (file) onFileSelected(file);
    },
    [onFileSelected]
  );

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label="Upload a file to analyze"
      onClick={openPicker}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openPicker();
        }
      }}
      onDragEnter={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={(e) => {
        e.preventDefault();
        setDragOver(false);
      }}
      onDrop={handleDrop}
      className={`cursor-pointer rounded-lg border-2 border-dashed p-11 text-center transition-colors ${
        dragOver ? 'border-brand-cyan bg-brand-cyan/5' : 'border-border bg-[radial-gradient(circle_at_50%_0%,rgba(59,124,246,0.08),transparent_60%)]'
      }`}
    >
      <div className="text-4xl">📄</div>
      <h3 className="mt-3 font-display text-lg font-semibold">Drop a PDF or .txt file here</h3>
      <p className="mt-1 text-sm text-ink-dim">or tap to choose a file from your device</p>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          openPicker();
        }}
        className="mt-5 rounded-full bg-brand-gradient px-6 py-2.5 font-semibold text-[#04050a]"
      >
        Choose file
      </button>
      <input
        ref={inputRef}
        type="file"
        accept=".pdf,.txt,text/plain,application/pdf"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFileSelected(file);
          e.target.value = '';
        }}
      />
      <div className="mt-4 text-xs text-ink-faint">
        Max file size {Math.round(maxBytes / (1024 * 1024))} MB in this build · Processed locally · Nothing is
        uploaded
      </div>
    </div>
  );
}
