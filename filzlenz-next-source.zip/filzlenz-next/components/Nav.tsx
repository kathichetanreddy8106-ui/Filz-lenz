import Link from 'next/link';
import { LogoMark, Wordmark } from './Logo';

export function Nav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border-soft bg-bg/85 backdrop-blur-md pt-[env(safe-area-inset-top,0px)]">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-5">
        <Link href="/" className="flex items-center gap-2.5" aria-label="Filz Lenz home">
          <LogoMark size={28} />
          <Wordmark />
        </Link>
        <nav className="hidden gap-7 text-sm text-ink-dim md:flex">
          <Link href="/#features" className="hover:text-ink">Features</Link>
          <Link href="/#privacy" className="hover:text-ink">Privacy</Link>
          <Link href="/about" className="hover:text-ink">About</Link>
        </nav>
        <Link
          href="/analyze"
          className="rounded-full bg-brand-gradient px-5 py-2.5 text-sm font-semibold text-[#04050a] transition hover:shadow-[0_8px_24px_-8px_rgba(59,124,246,0.6)]"
        >
          Analyze a File
        </Link>
      </div>
    </header>
  );
}
