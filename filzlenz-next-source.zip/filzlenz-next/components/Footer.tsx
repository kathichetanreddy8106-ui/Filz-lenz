export function Footer() {
  return (
    <footer className="border-t border-border-soft py-10 text-sm text-ink-faint">
      <div className="mx-auto flex max-w-5xl flex-col gap-3 px-5 sm:flex-row sm:justify-between">
        <p>
          <span className="font-semibold text-ink">Filz Lenz</span> — document intelligence, processed locally. Not
          legal, financial, or medical advice.
        </p>
        <p>Zero paid APIs · Zero server upload of your files</p>
      </div>
    </footer>
  );
}
