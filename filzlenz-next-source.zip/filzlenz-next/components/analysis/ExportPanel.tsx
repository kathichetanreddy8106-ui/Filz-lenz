'use client';

import type { AnalysisResult } from '../../types/analysis';
import { buildJsonExport, buildTxtExport, buildMarkdownExport, triggerDownload } from '../../utils/exportPayloads';

export function ExportPanel({ result }: { result: AnalysisResult }) {
  return (
    <div>
      <p className="mb-4 text-ink-dim">
        Download this analysis. No file content ever leaves your browser to produce these exports — they are
        generated locally.
      </p>
      <div className="flex flex-wrap gap-2.5">
        <button
          onClick={() => triggerDownload(buildJsonExport(result), 'application/json', 'filzlenz-analysis.json')}
          className="rounded-full border border-border px-4.5 py-2.5 text-sm hover:border-ink-dim"
        >
          Export analysis (.json)
        </button>
        <button
          onClick={() => triggerDownload(buildTxtExport(result), 'text/plain', 'filzlenz-analysis.txt')}
          className="rounded-full border border-border px-4.5 py-2.5 text-sm hover:border-ink-dim"
        >
          Export analysis (.txt)
        </button>
        <button
          onClick={() => triggerDownload(buildMarkdownExport(result), 'text/markdown', 'filzlenz-analysis.md')}
          className="rounded-full border border-border px-4.5 py-2.5 text-sm hover:border-ink-dim"
        >
          Export analysis (.md)
        </button>
      </div>
    </div>
  );
}
