'use client';

import { useState } from 'react';
import { askQuestion } from '../../lib/core';
import type { AnalysisResult, AskResultHit } from '../../types/analysis';

interface HistoryItem {
  question: string;
  answered: boolean;
  hit?: AskResultHit;
  reason?: string;
  citeLabel?: string;
}

export function AskPanel({ result }: { result: AnalysisResult }) {
  const [question, setQuestion] = useState('');
  const [history, setHistory] = useState<HistoryItem[]>([]);

  function ask() {
    const q = question.trim();
    if (!q) return;
    const res = askQuestion(result.qaIndex, q, { threshold: 0.1, topK: 1 });

    if (!res.answered) {
      setHistory((h) => [{ question: q, answered: false, reason: res.reason }, ...h]);
      setQuestion('');
      return;
    }

    const hit = res.results[0];
    const rec = result.sentenceRecords[hit.index];
    const citeLabel = result.isPdf
      ? `Page ${rec.pageNumber ?? '?'}${rec.heading ? ` — ${rec.heading}` : ''}`
      : rec.heading ?? 'Source excerpt';

    setHistory((h) => [{ question: q, answered: true, hit, citeLabel }, ...h]);
    setQuestion('');
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap gap-2.5">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask()}
          placeholder="Ask a question about this file…"
          aria-label="Ask a question about this file"
          className="min-w-[200px] flex-1 rounded-full border border-border bg-bg-elevated px-4.5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-cyan"
        />
        <button onClick={ask} className="rounded-full bg-brand-gradient px-5 py-3 font-semibold text-[#04050a]">
          Ask
        </button>
      </div>

      <div className="space-y-3">
        {history.map((item, i) => (
          <div key={i} className="rounded-lg border-l-[3px] border-l-brand-cyan border-y border-r border-border bg-surface p-4">
            <div className="mb-2 text-sm text-ink-faint">Q: {item.question}</div>
            {item.answered && item.hit ? (
              <>
                <div className="text-[1.02rem]">{item.hit.text}</div>
                <span className="mt-3 inline-flex items-center gap-1.5 rounded-md border border-border bg-bg-elevated px-2.5 py-1 text-xs text-ink-dim">
                  📍 {item.citeLabel}
                </span>
                <div className="mt-2.5 text-xs text-ink-faint">
                  Match confidence {Math.round(item.hit.score * 100)}% — extracted directly from the file, not
                  generated.
                </div>
              </>
            ) : (
              <div className="text-[1.02rem]">{item.reason}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
