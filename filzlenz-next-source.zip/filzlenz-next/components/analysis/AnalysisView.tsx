'use client';

import { useState } from 'react';
import type { AnalysisResult, HeadingInfo } from '../../types/analysis';
import { formatBytes } from '../../utils/format';
import { OverviewPanel } from './OverviewPanel';
import { StructurePanel } from './StructurePanel';
import { SummaryPanel } from './SummaryPanel';
import { EntitiesPanel } from './EntitiesPanel';
import { TablesPanel } from './TablesPanel';
import { AskPanel } from './AskPanel';
import { FullTextPanel, type JumpTarget } from './FullTextPanel';
import { ExportPanel } from './ExportPanel';

const TABS = ['Overview', 'Structure', 'Summary', 'Entities', 'Tables', 'Ask', 'Full text', 'Export'] as const;
type Tab = (typeof TABS)[number];

export function AnalysisView({ result, onReset }: { result: AnalysisResult; onReset: () => void }) {
  const [tab, setTab] = useState<Tab>('Overview');
  const [jumpTarget, setJumpTarget] = useState<JumpTarget | null>(null);

  function handleJump(heading: HeadingInfo) {
    setJumpTarget({ pageNumber: heading.pageNumber, headingText: heading.text });
    setTab('Full text');
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3.5">
        <div>
          <div className="break-words text-lg font-bold">{result.fileName}</div>
          <div className="text-sm text-ink-faint">
            {result.stats.fileType} · {formatBytes(result.stats.fileSizeBytes)}
            {result.stats.pageCount ? ` · ${result.stats.pageCount} pages` : ''}
          </div>
        </div>
        <button onClick={onReset} className="rounded-full border border-border px-4 py-2 text-sm hover:border-ink-dim">
          Analyze another file
        </button>
      </div>

      <div className="mb-6 flex gap-1.5 overflow-x-auto border-b border-border-soft" role="tablist" aria-label="Analysis sections">
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`-mb-px whitespace-nowrap border-b-2 px-3.5 py-2.5 text-sm font-semibold ${
              tab === t ? 'border-brand-cyan text-ink' : 'border-transparent text-ink-dim hover:text-ink'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && <OverviewPanel result={result} />}
      {tab === 'Structure' && <StructurePanel headings={result.headings} onJump={handleJump} />}
      {tab === 'Summary' && <SummaryPanel summary={result.summary} />}
      {tab === 'Entities' && <EntitiesPanel entities={result.entities} />}
      {tab === 'Tables' && <TablesPanel tables={result.tables} />}
      {tab === 'Ask' && <AskPanel result={result} />}
      {tab === 'Full text' && <FullTextPanel result={result} jumpTarget={jumpTarget} />}
      {tab === 'Export' && <ExportPanel result={result} />}
    </div>
  );
}
