'use client';

import type { TableBlock } from '../../types/analysis';
import { buildTableCsv, buildTableJson, triggerDownload } from '../../utils/exportPayloads';

export function TablesPanel({ tables }: { tables: TableBlock[] }) {
  if (tables.length === 0) {
    return <p className="text-sm text-ink-faint">No tables were detected in this document.</p>;
  }
  return (
    <div className="space-y-8">
      {tables.map((t, i) => (
        <div key={i}>
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <strong>
              Table {i + 1}
              {t.pageNumber ? ` — page ${t.pageNumber}` : ''}
            </strong>
            <span className="text-xs text-ink-faint">
              {t.rowCount} rows × {t.columnCount} cols · detected heuristically
            </span>
          </div>
          <div className="mb-3 flex gap-2">
            <button
              onClick={() => triggerDownload(buildTableCsv(t), 'text/csv', `filzlenz-table-${i + 1}.csv`)}
              className="rounded-full border border-border px-3.5 py-1.5 text-sm hover:border-ink-dim"
            >
              Export CSV
            </button>
            <button
              onClick={() => triggerDownload(buildTableJson(t), 'application/json', `filzlenz-table-${i + 1}.json`)}
              className="rounded-full border border-border px-3.5 py-1.5 text-sm hover:border-ink-dim"
            >
              Export JSON
            </button>
          </div>
          <div className="overflow-x-auto rounded-sm border border-border">
            <table className="w-full border-collapse text-sm">
              <tbody>
                {t.rows.map((row, ri) => (
                  <tr key={ri}>
                    {row.map((cell, ci) => (
                      <td key={ci} className="border border-border px-2.5 py-1.5">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
}
