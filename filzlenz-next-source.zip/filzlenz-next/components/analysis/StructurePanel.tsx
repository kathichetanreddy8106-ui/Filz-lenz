import type { HeadingInfo } from '../../types/analysis';

export function StructurePanel({ headings, onJump }: { headings: HeadingInfo[]; onJump: (heading: HeadingInfo) => void }) {
  if (headings.length === 0) {
    return <p className="text-sm text-ink-faint">No clear headings or sections were detected in this document.</p>;
  }
  return (
    <ul className="divide-y divide-border-soft">
      {headings.map((h, i) => (
        <li key={i}>
          <button
            onClick={() => onJump(h)}
            className="flex w-full items-baseline gap-2.5 py-2.5 text-left hover:[&_span.htext]:text-brand-cyan"
          >
            <span className="min-w-[40px] text-xs text-ink-faint">{h.pageNumber ? `Page ${h.pageNumber}` : `H${h.level}`}</span>
            <span className="htext transition-colors">{h.text}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}
