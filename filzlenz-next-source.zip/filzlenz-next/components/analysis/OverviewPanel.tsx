import type { AnalysisResult } from '../../types/analysis';

function StatCard({ value, label }: { value: string | number; label: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface p-5 text-left">
      <div className="font-display text-2xl font-bold">{value}</div>
      <div className="mt-1 text-xs text-ink-faint">{label}</div>
    </div>
  );
}

export function OverviewPanel({ result }: { result: AnalysisResult }) {
  const { stats, languageInfo, headings, tables } = result;
  return (
    <div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard value={stats.pageCount ?? 'N/A'} label="Pages" />
        <StatCard value={stats.wordCount.toLocaleString()} label="Words" />
        <StatCard value={stats.charCount.toLocaleString()} label="Characters" />
        <StatCard value={stats.lineCount.toLocaleString()} label="Lines" />
        <StatCard value={`${stats.readingTimeMin} min`} label="Reading time" />
        <StatCard
          value={languageInfo.language}
          label={`Language${languageInfo.confidence ? ` (${languageInfo.confidence}% match)` : ''}`}
        />
        <StatCard value={headings.length} label="Headings detected" />
        <StatCard value={tables.length} label="Tables detected" />
      </div>
      <p className="mt-4 text-sm text-ink-faint">
        Counts and structure are computed directly from the extracted text. Where something can&apos;t be reliably
        detected, it is labeled &quot;Not detected&quot; rather than guessed.
      </p>
    </div>
  );
}
