'use client';

import { useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import type { AnalysisResult } from '../../types/analysis';

/**
 * Splits `text` around the first occurrence of `term` into safe React
 * nodes (never raw HTML). Uploaded document content is always untrusted,
 * so highlighting is done by composing plain-text React children, not by
 * building an HTML string and injecting it.
 */
function withHighlight(text: string, term: string | null): ReactNode {
  if (!term) return text;
  const idx = text.indexOf(term);
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="rounded bg-brand-cyan/30">{text.slice(idx, idx + term.length)}</mark>
      {text.slice(idx + term.length)}
    </>
  );
}

export interface JumpTarget {
  pageNumber: number | null;
  headingText: string;
}

export function FullTextPanel({ result, jumpTarget }: { result: AnalysisResult; jumpTarget: JumpTarget | null }) {
  const pageRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  useEffect(() => {
    if (!jumpTarget) return;
    const key = String(jumpTarget.pageNumber ?? 'single');
    const el = pageRefs.current.get(key);
    el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }, [jumpTarget]);

  if (!result.isPdf) {
    return (
      <div className="doc-textview max-h-[420px] overflow-y-auto whitespace-pre-wrap rounded-sm border border-border bg-bg-elevated p-4 text-sm leading-relaxed">
        {withHighlight(result.fullText, jumpTarget?.headingText ?? null)}
      </div>
    );
  }

  const byPage = new Map<number, string[]>();
  result.sentenceRecords.forEach((r) => {
    const key = r.pageNumber ?? 0;
    if (!byPage.has(key)) byPage.set(key, []);
    byPage.get(key)!.push(r.text);
  });
  const pages = [...byPage.keys()].sort((a, b) => a - b);

  return (
    <div className="doc-textview max-h-[420px] overflow-y-auto rounded-sm border border-border bg-bg-elevated p-4 text-sm leading-relaxed">
      {pages.map((p) => (
        <div
          key={p}
          ref={(el) => {
            if (el) pageRefs.current.set(String(p), el);
          }}
        >
          <div className="mt-3.5 border-t border-dashed border-border pt-2 text-xs text-ink-faint first:mt-0 first:border-t-0 first:pt-0">
            Page {p}
          </div>
          <span className="whitespace-pre-wrap">
            {withHighlight(byPage.get(p)!.join(' '), jumpTarget?.pageNumber === p ? jumpTarget.headingText : null)}
          </span>
        </div>
      ))}
    </div>
  );
}
