import type { ExtractedEntities } from '../../types/analysis';
import type { ReactNode } from 'react';

function EntityGroup({ title, note, children }: { title: string; note?: string; children: ReactNode }) {
  return (
    <div className="mb-6">
      <h4 className="mb-2.5 text-sm font-semibold text-ink-dim">
        {title} {note && <span className="font-normal text-ink-faint">({note})</span>}
      </h4>
      {children}
    </div>
  );
}

function ChipRow({ items }: { items: string[] }) {
  if (items.length === 0) return <p className="text-sm text-ink-faint">Not detected</p>;
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((v, i) => (
        <span key={i} className="rounded-md border border-border bg-bg-elevated px-2.5 py-1.5 text-sm">
          {v}
        </span>
      ))}
    </div>
  );
}

export function EntitiesPanel({ entities }: { entities: ExtractedEntities }) {
  return (
    <div>
      <EntityGroup title="Emails"><ChipRow items={entities.emails} /></EntityGroup>
      <EntityGroup title="Phone numbers"><ChipRow items={entities.phones} /></EntityGroup>
      <EntityGroup title="URLs"><ChipRow items={entities.urls} /></EntityGroup>
      <EntityGroup title="Dates"><ChipRow items={entities.dates} /></EntityGroup>
      <EntityGroup title="Money / currency amounts"><ChipRow items={entities.money} /></EntityGroup>
      <EntityGroup title="Percentages"><ChipRow items={entities.percentages} /></EntityGroup>
      <EntityGroup title="Candidate names / organizations" note="heuristic — may include false positives">
        {entities.nameOrgCandidates.length === 0 ? (
          <p className="text-sm text-ink-faint">Not detected</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {entities.nameOrgCandidates.map((c, i) => (
              <span key={i} className="rounded-md border border-border bg-bg-elevated px-2.5 py-1.5 text-sm">
                {c.text} <span className="text-ink-faint">×{c.occurrences}</span>
              </span>
            ))}
          </div>
        )}
      </EntityGroup>
      <EntityGroup title="Other numbers"><ChipRow items={entities.numbers.slice(0, 40)} /></EntityGroup>
    </div>
  );
}
