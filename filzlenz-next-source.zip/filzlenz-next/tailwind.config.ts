import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#05070d',
        'bg-elevated': '#0b0f1c',
        surface: '#11172a',
        border: '#232b45',
        'border-soft': '#1a2036',
        ink: '#eef1fb',
        'ink-dim': '#97a0c3',
        'ink-faint': '#5c6584',
        brand: {
          blue: '#3b7cf6',
          cyan: '#34d3e8',
          violet: '#9061f9',
        },
      },
      fontFamily: {
        display: ['var(--font-sora)', 'Inter', 'sans-serif'],
        sans: ['var(--font-inter)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      borderRadius: {
        sm: '10px',
        DEFAULT: '16px',
        lg: '22px',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(120deg, #3b7cf6, #34d3e8 55%, #9061f9)',
      },
    },
  },
  plugins: [],
};

export default config;
