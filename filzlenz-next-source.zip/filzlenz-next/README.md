# Filz Lenz

Local, deterministic file intelligence. Upload a PDF or `.txt` file and get a File X-Ray, structure map, extractive summary, entity extraction, table detection, and a citation-backed "Ask this file" — with **zero paid APIs** and **zero file upload to any server**.

> "See deeper. Understand more."

---

## What this is (and isn't)

Filz Lenz analyzes files entirely inside your browser using deterministic algorithms — regex-based extraction, word-frequency scoring, and TF-IDF-style retrieval. **There is no AI language model involved.** Nothing is invented: where something can't be reliably detected, the app says "Not detected" rather than guessing.

This is the productionized core (Slice 2). It intentionally does **not** yet include OCR, DOCX/PPTX/XLSX support, multi-file workspaces, or any of the other later-phase modules — see [Limitations](#limitations).

## Architecture

```
app/                    Next.js App Router pages
  page.tsx              Landing page
  analyze/page.tsx       File analysis flow
  about/page.tsx         Product info
components/             UI components
  analysis/              One component per File X-Ray tab
lib/
  core.ts                The analysis engine — pure functions, no DOM dependency
  pdf.ts                 Client-only PDF.js wrapper (dynamically imported)
services/
  analysisService.ts     Orchestration: validation + page-aware analysis pipeline
hooks/
  useFileAnalysis.ts      React state machine wrapping the service
types/
  analysis.ts             Shared TypeScript interfaces
utils/
  format.ts, exportPayloads.ts   Formatting + JSON/TXT/Markdown/CSV export builders
tests/
  core.test.ts, analysisService.test.ts, exportPayloads.test.ts
```

**Why this structure:** `lib/core.ts` has no framework or DOM dependency, so it's unit-testable in plain Node and safe to import from both client and server code. `services/analysisService.ts` is the only place that knows about pages/files; it's also framework-free and unit-tested directly. Only the `components/` and `hooks/` layers touch React, and only `lib/pdf.ts` and the upload flow touch browser-only APIs (`File`, `FileReader`, PDF.js) — those are dynamically imported and marked `'use client'` so they never execute during server rendering.

## Local-first privacy

Your file is read and analyzed entirely in your browser. Nothing is uploaded to a server. No paid AI API is called to produce any result. Closing the tab clears everything; nothing is stored unless you use an export button.

## Supported formats

- **PDF** (text-layer extraction via `pdfjs-dist`, bundled through the project's own build — not a runtime CDN)
- **Plain text** (`.txt`)

## Setup

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

> **Note on this repository's own build environment:** the sandbox this code was written in blocks all access to `registry.npmjs.org` (outbound network is disabled by policy). Running `npm install` there fails immediately with:
> ```
> npm error code E403
> npm error 403 403 Forbidden - GET https://registry.npmjs.org/@types%2fnode
> npm error 403 In most cases, you or one of your dependencies are requesting
> npm error 403 a package version that is forbidden by your security policy, or
> npm error 403 on a server you do not have access to.
> ```
> This is an environment restriction, not a problem with the project — on a normal machine or in GitHub Actions/Vercel, `npm install` reaches the public registry and this error will not occur. See **Verification performed in this environment** below for what was independently confirmed despite this restriction.

## Testing

Tests are framework-free (Node's built-in `assert`, run via `tsx`) so they need no additional install beyond `npm install`:

```bash
npm test
```

This runs `tests/core.test.ts` (26 tests — the original prototype's 19 tests, ported unchanged as a regression check, plus 7 new tests for malformed input, empty documents, Unicode, large documents, and duplicate-entity handling), `tests/analysisService.test.ts` (9 tests covering file validation, page-citation mapping, and the "no extractable text" PDF error path), and `tests/exportPayloads.test.ts` (6 tests covering JSON/TXT/Markdown/CSV export generation).

Type-check:

```bash
npm run typecheck
```

## Production build

```bash
npm run build
npm start
```

## Deploying to Vercel

1. Push this repository to GitHub.
2. Import it in Vercel.
3. No environment variables are required for core functionality — leave the environment variables section empty.
4. Deploy. Framework preset: Next.js (auto-detected).

## Zero-cost audit

| Dependency | Purpose | Cost |
|---|---|---|
| `next`, `react`, `react-dom` | Application framework | Free, open-source |
| `pdfjs-dist` | Client-side PDF text extraction | Free, open-source (Apache-2.0), bundled — no CDN, no API key |
| `tailwindcss` | Styling | Free, open-source |
| `typescript`, `tsx` | Types + test runner | Free, open-source |

No AI API (OpenAI, Claude, Gemini, or otherwise), no paid OCR, no paid database, no paid storage, no paid backend, no paid analytics, and no other paid SaaS dependency is used anywhere in this codebase.

## Limitations

- **Formats:** PDF (text-layer only) and `.txt`. DOCX, PPTX, XLSX, and images are not implemented — not stubbed, just absent.
- **Scanned PDFs:** no extractable text layer means no OCR runs; the app reports this rather than returning an empty result silently.
- **Name/organization detection** is a labeled heuristic (capitalized-phrase matching), not true named-entity recognition. Expect some false positives on proper-noun-heavy text — including the pattern `"Word. Capitalized"` occasionally being picked up as a two-word candidate, since the regex doesn't treat a sentence-ending period as a boundary. Already disclosed in the UI as heuristic; not changed in this pass since it's a pre-existing property of the (intentionally unmodified) entity-extraction algorithm, not a crash or regression.
- **Single-word headings** (e.g. a lone line reading "Conclusion") are not detected as headings — only numbered (`1. Conclusion`), markdown (`# Conclusion`), all-caps, or multi-word title-case headings are. This is intentional (avoids false-positiving on any capitalized word) and predates this migration.
- **Language detection** covers English, Spanish, French, German, and Portuguese via stopword overlap; anything else reports "Not detected."
- **"Ask this file"** retrieves and cites the most relevant existing sentence via TF-IDF cosine similarity — it does not generate new text, and explicitly refuses to answer when confidence is low.
- **Browser support:** the sentence-splitting regex uses a lookbehind assertion, requiring a reasonably modern browser (Chrome/Edge 88+, Firefox 78+, Safari 16.4+).
- **Not build-verified with `npm install && npm run build`.** The environment this code was written and tested in has no network access — `npm install` fails with `403 Forbidden` against `registry.npmjs.org` (see Verification below for the exact error and what was independently confirmed instead).

## Verification performed in this environment (stabilization pass)

`npm install` cannot run here (see below), so `next build`/`next lint` could not be executed. Everything that *could* be verified without installing anything was:

- **All 47 tests pass** via `npm test` (`tsx`, Node's built-in `assert` — no install required).
- **`lib/core.ts`, `lib/pdf.ts`'s pure helper, `types/`, `services/`, `utils/`** type-check cleanly in TypeScript strict mode (`npx tsc -p tsconfig.core.json`).
- **Every relative import in the project** (43 of them) was statically verified to resolve to a real file.
- **Client/server boundaries** were audited: every file using React hooks has `'use client'`; `pdfjs-dist` is only ever dynamically imported; no server-only Node APIs (`fs`, `path`) appear in browser-facing code.
- **Real end-to-end functional testing in a headless browser** (Playwright/Chromium, which is available in this sandbox) against the exact engine and orchestration logic shipped in `lib/core.ts` and `services/analysisService.ts`, using a genuine PDF (generated with `pdf-lib`) run through a genuine local copy of `pdf.js` (since `cdnjs` is also blocked from the browser in this sandbox) and a multi-section `.txt` fixture. This confirmed working: PDF text extraction, page/word/char counts, heading detection, entity extraction (emails/dates/money/percentages), table detection (including CSV/JSON export payloads), extractive summaries, Ask File (both a correctly-answered question with citation, and a correct refusal on an unanswerable one), and mobile layout at a 375px viewport across all eight tabs with zero horizontal overflow.
- This testing surfaced and fixed two real bugs — see below.

### Bugs found and fixed in this pass

1. **PDF text extraction discarded all line breaks.** `lib/pdf.ts` joined `pdf.js`'s text items with a bare space, collapsing every page into a single line. Since `extractHeadings()` and `detectTables()` both split on `\n`, this silently meant **headings and tables were never detected in any real PDF** — confirmed by generating a real test PDF and inspecting `pdf.js`'s actual output. Fixed by adding `lib/pdfText.ts`, which reconstructs line breaks from `pdf.js`'s per-item `hasEOL` flag (a standard technique for this library). Covered by `tests/pdfText.test.ts`, including a test that proves the old behavior really did fail before the fix.
2. **Every sentence in a document was cited under its first heading, not its actual section.** The heading-to-sentence attribution in `services/analysisService.ts` labeled an entire "page" of sentences with that page's *first* detected heading. Since a `.txt` file is always exactly one page, this meant **every citation in a multi-section text file pointed at section one**, regardless of where the answer actually came from — confirmed live (a question answered from the "Key Metrics" section was cited as "Q3 Business Review", the document's first heading). Fixed by re-attributing sentences at paragraph granularity to the nearest preceding heading, without changing `splitSentences()` or any other preserved core algorithm. Covered by a new regression test in `tests/analysisService.test.ts` and re-verified live in the browser.

## Not legal, financial, or medical advice

Filz Lenz provides document analysis for informational purposes. Extracted figures, dates, and other detected information may require independent verification.
