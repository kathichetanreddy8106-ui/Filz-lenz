import { Nav } from '../../components/Nav';
import { Footer } from '../../components/Footer';

export const metadata = { title: 'About — Filz Lenz' };

export default function AboutPage() {
  return (
    <>
      <Nav />
      <main className="mx-auto max-w-3xl px-5 py-16">
        <h1 className="font-display text-3xl font-bold">About Filz Lenz</h1>
        <p className="mt-4 text-ink-dim">
          Filz Lenz is a local, deterministic file-intelligence tool. Upload a PDF or text file and it computes
          statistics, detects structure and tables, extracts entities, writes an extractive summary, and answers
          questions using a local retrieval engine — all inside your browser.
        </p>

        <h2 className="mt-8 font-display text-xl font-bold">How it works</h2>
        <p className="mt-2 text-ink-dim">
          There is no AI language model involved. Every result comes from deterministic algorithms — regular
          expressions, word-frequency scoring, and TF-IDF-style cosine similarity — running entirely in JavaScript in
          your browser. Nothing is invented; where something can't be reliably detected, it's labeled "Not detected"
          rather than guessed.
        </p>

        <h2 className="mt-8 font-display text-xl font-bold">Current limitations</h2>
        <ul className="mt-2 list-disc space-y-1.5 pl-5 text-ink-dim">
          <li>Supported formats: PDF (text-layer) and .txt. DOCX, PPTX, XLSX, and images are not yet supported.</li>
          <li>Scanned/image-only PDFs have no extractable text layer — OCR is not implemented in this version.</li>
          <li>Name/organization detection is a labeled heuristic, not true named-entity recognition.</li>
          <li>Language detection covers English, Spanish, French, German, and Portuguese.</li>
          <li>"Ask this file" retrieves and cites your file's own sentences — it does not generate new text.</li>
        </ul>

        <h2 className="mt-8 font-display text-xl font-bold">Not legal, financial, or medical advice</h2>
        <p className="mt-2 text-ink-dim">
          Filz Lenz provides document analysis for informational purposes. Extracted figures, dates, and other
          detected information may require independent verification.
        </p>
      </main>
      <Footer />
    </>
  );
}
