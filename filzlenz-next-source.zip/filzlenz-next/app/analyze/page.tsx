'use client';

import { Nav } from '../../components/Nav';
import { Footer } from '../../components/Footer';
import { UploadZone } from '../../components/UploadZone';
import { AnalysisView } from '../../components/analysis/AnalysisView';
import { useFileAnalysis } from '../../hooks/useFileAnalysis';

export default function AnalyzePage() {
  const { status, analyze, reset, maxFileBytes } = useFileAnalysis();

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl px-5 py-12">
        {status.phase !== 'done' && (
          <>
            <div className="mb-8 max-w-[62ch]">
              <h1 className="font-display text-2xl font-bold sm:text-3xl">Analyze a file</h1>
              <p className="mt-2 text-ink-dim">
                Supported now: PDF and plain text (.txt). Other formats will be added in a future version rather than
                faked here.
              </p>
            </div>

            <UploadZone onFileSelected={analyze} maxBytes={maxFileBytes} />

            {(status.phase === 'reading' || status.phase === 'analyzing') && (
              <div className="mt-5 flex items-center gap-2.5 text-sm text-ink-dim">
                <span
                  className="h-4 w-4 animate-spin rounded-full border-2 border-border border-t-brand-cyan"
                  aria-hidden="true"
                />
                <span>{status.detail}</span>
              </div>
            )}

            {status.phase === 'error' && (
              <div className="mt-5 rounded-sm border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-300">
                {status.message}
              </div>
            )}
          </>
        )}

        {status.phase === 'done' && <AnalysisView result={status.result} onReset={reset} />}
      </main>
      <Footer />
    </>
  );
}
