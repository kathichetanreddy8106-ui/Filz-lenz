import Link from 'next/link';
import { Nav } from '../components/Nav';
import { Footer } from '../components/Footer';

const FEATURES = [
  {
    icon: '🩻',
    title: 'File X-Ray',
    body: 'Word, character and line counts, page count, language, reading time, headings and tables — computed directly from your file.',
  },
  {
    icon: '🧭',
    title: 'Structure map',
    body: 'Detected headings and sections as a clickable outline that jumps to that part of the extracted text.',
  },
  {
    icon: '🧬',
    title: 'Extractive summary',
    body: 'One-sentence, short, and extended summaries from frequency-based sentence ranking — not a hosted language model.',
  },
  {
    icon: '🏷️',
    title: 'Entity extraction',
    body: 'Emails, phone numbers, URLs, dates, money, percentages, and candidate names/organizations, pattern-matched from the text.',
  },
  {
    icon: '💬',
    title: 'Ask this file',
    body: 'A local TF-IDF retrieval engine finds the most relevant sentence for your question and cites its page or section.',
  },
  {
    icon: '📤',
    title: 'Export',
    body: 'Download the full analysis as JSON, Markdown, or plain text — generated entirely on your device.',
  },
];

export default function LandingPage() {
  return (
    <>
      <Nav />
      <main>
        <section className="px-5 pb-14 pt-16 sm:pt-20">
          <div className="mx-auto max-w-5xl">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border px-3.5 py-1.5 text-sm text-ink-dim">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-cyan shadow-[0_0_8px_#34d3e8]" />
              Runs locally in your browser — no file leaves your device
            </div>
            <h1 className="max-w-[14ch] font-display text-4xl font-extrabold leading-tight sm:text-6xl">
              See deeper.
              <br />
              <span className="bg-brand-gradient bg-clip-text text-transparent">Understand more.</span>
            </h1>
            <p className="mt-5 max-w-[56ch] text-lg text-ink-dim">
              Upload a PDF or text file and Filz Lenz maps its structure, pulls out the entities and numbers that
              matter, writes an extractive summary, and answers your questions with cited evidence — without sending
              your file to any server.
            </p>
            <div className="mt-8 flex flex-wrap gap-3.5">
              <Link href="/analyze" className="rounded-full bg-brand-gradient px-6 py-3 font-semibold text-[#04050a]">
                Analyze a File
              </Link>
              <Link href="#features" className="rounded-full border border-border px-6 py-3 font-semibold hover:border-ink-dim">
                Explore features
              </Link>
            </div>
          </div>
        </section>

        <section id="features" className="border-t border-border-soft px-5 py-16">
          <div className="mx-auto max-w-5xl">
            <div className="mb-9 max-w-[62ch]">
              <h2 className="font-display text-2xl font-bold sm:text-3xl">What Filz Lenz does today</h2>
              <p className="mt-2 text-ink-dim">
                This is the core File Intelligence engine — the foundation the fuller Filz Lenz File OS is built on.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <div key={f.title} className="rounded-lg border border-border bg-surface p-5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-[10px] border border-border bg-gradient-to-br from-brand-blue/15 to-brand-violet/15 text-lg">
                    {f.icon}
                  </div>
                  <h3 className="mt-3 font-semibold">{f.title}</h3>
                  <p className="mt-1.5 text-sm text-ink-dim">{f.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="privacy" className="border-t border-border-soft px-5 py-16">
          <div className="mx-auto max-w-5xl max-w-[62ch]">
            <h2 className="font-display text-2xl font-bold sm:text-3xl">Privacy-first, by construction</h2>
            <p className="mt-2 text-ink-dim">
              Your file is read and analyzed entirely inside this browser tab using JavaScript. Nothing is uploaded to
              a server, and no paid AI API is called to generate any result on this page. Closing the tab clears
              everything — nothing is stored unless you choose to export it.
            </p>
          </div>
        </section>

        <section className="border-t border-border-soft px-5 py-16">
          <div className="mx-auto flex max-w-5xl flex-col items-start gap-5 rounded-lg border border-border bg-surface p-8 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="font-display text-xl font-bold">Ready to see what's inside a file?</h2>
              <p className="mt-1 text-sm text-ink-dim">PDF and .txt supported. No account needed.</p>
            </div>
            <Link href="/analyze" className="rounded-full bg-brand-gradient px-6 py-3 font-semibold text-[#04050a]">
              Analyze a File
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
