export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

/**
 * Minimal, dependency-free HTML escaping for rendering untrusted document
 * content. Uploaded file content is always untrusted — this must be used
 * anywhere extracted text is rendered outside of React's own JSX escaping
 * (e.g. when building strings for download, or dangerouslySetInnerHTML is
 * ever considered — which this project avoids entirely, see FullTextPanel).
 */
export function escapeHtml(input: string): string {
  return String(input).replace(/[&<>"']/g, (c) => {
    switch (c) {
      case '&': return '&amp;';
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '"': return '&quot;';
      case "'": return '&#39;';
      default: return c;
    }
  });
}
