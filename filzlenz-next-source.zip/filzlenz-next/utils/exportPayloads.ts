import type { AnalysisResult, TableBlock } from '../types/analysis';
import { formatBytes } from './format';

/**
 * These builders are pure string-generation functions with no DOM
 * dependency, so they can be unit tested directly in Node (see
 * tests/exportPayloads.test.ts) even though the actual "download" action
 * (triggerDownload, below) needs a browser.
 */

export function buildJsonExport(result: AnalysisResult): string {
  const payload = {
    fileName: result.fileName,
    stats: result.stats,
    language: result.languageInfo,
    headings: result.headings,
    tables: result.tables.map((t) => ({
      pageNumber: t.pageNumber,
      rowCount: t.rowCount,
      columnCount: t.columnCount,
      rows: t.rows,
    })),
    entities: result.entities,
    summary: result.summary,
  };
  return JSON.stringify(payload, null, 2);
}

export function buildTxtExport(result: AnalysisResult): string {
  const s = result;
  const lines: string[] = [];
  lines.push('FILZ LENZ — ANALYSIS REPORT');
  lines.push(`File: ${s.fileName}`);
  lines.push(
    `Type: ${s.stats.fileType} | Size: ${formatBytes(s.stats.fileSizeBytes)}` +
      (s.stats.pageCount ? ` | Pages: ${s.stats.pageCount}` : '')
  );
  lines.push(`Words: ${s.stats.wordCount} | Characters: ${s.stats.charCount} | Reading time: ${s.stats.readingTimeMin} min`);
  lines.push(`Language: ${s.languageInfo.language}`);
  lines.push('');
  lines.push(`SUMMARY (short): ${s.summary.short}`);
  lines.push('');
  lines.push(`HEADINGS: ${s.headings.map((h) => h.text).join(' | ') || 'None detected'}`);
  lines.push('');
  lines.push(`EMAILS: ${s.entities.emails.join(', ') || 'Not detected'}`);
  lines.push(`DATES: ${s.entities.dates.join(', ') || 'Not detected'}`);
  lines.push(`MONEY: ${s.entities.money.join(', ') || 'Not detected'}`);
  lines.push(`PERCENTAGES: ${s.entities.percentages.join(', ') || 'Not detected'}`);
  return lines.join('\n');
}

export function buildMarkdownExport(result: AnalysisResult): string {
  const s = result;
  const lines: string[] = [];
  lines.push(`# Filz Lenz analysis — ${s.fileName}`);
  lines.push('');
  lines.push(
    `**Type:** ${s.stats.fileType} · **Size:** ${formatBytes(s.stats.fileSizeBytes)}` +
      (s.stats.pageCount ? ` · **Pages:** ${s.stats.pageCount}` : '')
  );
  lines.push(
    `**Words:** ${s.stats.wordCount} · **Characters:** ${s.stats.charCount} · **Reading time:** ${s.stats.readingTimeMin} min · **Language:** ${s.languageInfo.language}`
  );
  lines.push('');
  lines.push('## Summary');
  lines.push(s.summary.short || '_Not enough text to summarize._');
  lines.push('');
  if (s.headings.length) {
    lines.push('## Structure');
    s.headings.forEach((h) => lines.push(`${'  '.repeat(Math.max(0, h.level - 1))}- ${h.text}`));
    lines.push('');
  }
  lines.push('## Entities');
  lines.push(`- **Emails:** ${s.entities.emails.join(', ') || 'Not detected'}`);
  lines.push(`- **Dates:** ${s.entities.dates.join(', ') || 'Not detected'}`);
  lines.push(`- **Money:** ${s.entities.money.join(', ') || 'Not detected'}`);
  lines.push(`- **Percentages:** ${s.entities.percentages.join(', ') || 'Not detected'}`);
  return lines.join('\n');
}

export function buildTableCsv(table: TableBlock): string {
  return table.rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
}

export function buildTableJson(table: TableBlock): string {
  return JSON.stringify(table.rows, null, 2);
}

/**
 * Browser-only. Triggers a client-side file download from an in-memory
 * string — never touches a server. Guarded so it's a safe no-op-with-warning
 * if somehow invoked outside a browser (e.g. during SSR).
 */
export function triggerDownload(content: string, mimeType: string, filename: string): void {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    console.warn('triggerDownload called outside the browser; ignoring.');
    return;
  }
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
