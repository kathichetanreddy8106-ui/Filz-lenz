/**
 * Shared types for Filz Lenz's local analysis engine.
 * Mirrors the shape of data produced by lib/core.ts, unchanged in meaning
 * from the original prototype's `state` object — just given real types.
 */

export type SupportedMime = 'application/pdf' | 'text/plain';

export interface LanguageInfo {
  language: string; // human-readable name, or "Not detected"
  confidence: number; // 0-100, heuristic stopword-overlap score
}

export interface HeadingInfo {
  text: string;
  lineIndex: number;
  level: number;
  kind: 'markdown' | 'numbered' | 'references' | 'allcaps' | 'titlecase';
  pageNumber: number | null; // null for .txt (no page concept)
}

export interface TableBlock {
  startLine: number;
  endLine: number;
  rowCount: number;
  columnCount: number;
  rows: string[][];
  pageNumber: number | null;
}

export interface EntityCandidate {
  text: string;
  occurrences: number;
}

export interface ExtractedEntities {
  emails: string[];
  urls: string[];
  phones: string[];
  dates: string[];
  money: string[];
  percentages: string[];
  numbers: string[];
  /** Heuristic capitalized-phrase candidates — explicitly NOT true NER. */
  nameOrgCandidates: EntityCandidate[];
}

export interface SummaryResult {
  oneSentence: string;
  short: string;
  extended: string;
  sentenceCount: number;
}

export interface SentenceRecord {
  text: string;
  pageNumber: number | null;
  heading: string | null;
}

export interface FileStats {
  fileType: string;
  fileSizeBytes: number;
  pageCount: number | null;
  wordCount: number;
  charCount: number;
  lineCount: number;
  readingTimeMin: number;
}

export interface QaVector {
  [term: string]: number;
}

export interface QaIndex {
  idf: Record<string, number>;
  vectors: QaVector[];
  sentences: string[];
}

export interface AskResultHit {
  index: number;
  score: number;
  text: string;
}

export interface AskResult {
  answered: boolean;
  results: AskResultHit[];
  reason?: string;
}

export interface AnalysisResult {
  fileName: string;
  isPdf: boolean;
  stats: FileStats;
  languageInfo: LanguageInfo;
  headings: HeadingInfo[];
  tables: TableBlock[];
  entities: ExtractedEntities;
  summary: SummaryResult;
  sentenceRecords: SentenceRecord[];
  qaIndex: QaIndex;
  fullText: string;
}

export interface PageText {
  pageNumber: number | null;
  text: string;
}

/** Discriminated status union driving the upload/analysis UI. */
export type AnalysisStatus =
  | { phase: 'idle' }
  | { phase: 'reading'; detail: string }
  | { phase: 'analyzing'; detail: string }
  | { phase: 'done'; result: AnalysisResult }
  | { phase: 'error'; message: string };
