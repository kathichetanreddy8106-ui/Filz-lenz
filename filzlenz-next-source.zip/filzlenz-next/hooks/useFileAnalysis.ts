'use client';

import { useCallback, useState } from 'react';
import { validateFile, analyzePages, MAX_FILE_BYTES } from '../services/analysisService';
import type { AnalysisStatus } from '../types/analysis';

export function useFileAnalysis() {
  const [status, setStatus] = useState<AnalysisStatus>({ phase: 'idle' });

  const reset = useCallback(() => setStatus({ phase: 'idle' }), []);

  const analyze = useCallback(async (file: File) => {
    try {
      const { isPdf, isTxt } = validateFile(file);

      if (isTxt) {
        setStatus({ phase: 'reading', detail: `Reading "${file.name}"…` });
        const text = await file.text();
        setStatus({ phase: 'analyzing', detail: 'Analyzing content…' });
        const result = analyzePages(file.name, file.size, [{ pageNumber: null, text }], false, null);
        setStatus({ phase: 'done', result });
        return;
      }

      if (isPdf) {
        setStatus({ phase: 'reading', detail: `Reading "${file.name}"…` });
        // Dynamically imported: keeps pdfjs-dist (and its worker) out of any
        // server-rendered path entirely.
        const { extractPdfPages } = await import('../lib/pdf');
        const pages = await extractPdfPages(file);
        setStatus({ phase: 'analyzing', detail: 'Analyzing content…' });
        const result = analyzePages(file.name, file.size, pages, true, pages.length);
        setStatus({ phase: 'done', result });
        return;
      }
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : 'Something went wrong while analyzing this file. Please try a different file.';
      setStatus({ phase: 'error', message });
    }
  }, []);

  return { status, analyze, reset, maxFileBytes: MAX_FILE_BYTES };
}
