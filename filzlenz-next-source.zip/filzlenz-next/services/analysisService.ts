import {
  countWords,
  countChars,
  countLines,
  estimateReadingTimeMinutes,
  detectLanguage,
  extractHeadings,
  detectTables,
  extractEntities,
  summarize,
  splitSentences,
  buildIndex,
} from '../lib/core';
import type { AnalysisResult, HeadingInfo, TableBlock, PageText, SentenceRecord } from '../types/analysis';

export const MAX_FILE_BYTES = 25 * 1024 * 1024;

export class UnsupportedFileError extends Error {}
export class EmptyContentError extends Error {}
export class FileTooLargeError extends Error {}

/**
 * Validates a picked file before any parsing happens. Kept separate from
 * parsing so the UI can show a precise, honest error immediately rather
 * than starting a doomed read.
 */
export function validateFile(file: File): { isPdf: boolean; isTxt: boolean } {
  const name = file.name || 'file';
  const ext = (name.split('.').pop() || '').toLowerCase();
  const isPdf = ext === 'pdf' || file.type === 'application/pdf';
  const isTxt = ext === 'txt' || file.type === 'text/plain';

  if (!isPdf && !isTxt) {
    throw new UnsupportedFileError(
      `"${name}" is not a supported file type in this build. Filz Lenz currently analyzes PDF and .txt files.`
    );
  }
  if (file.size === 0) {
    throw new EmptyContentError('This file appears to be empty (0 bytes), so there is nothing to analyze.');
  }
  if (file.size > MAX_FILE_BYTES) {
    throw new FileTooLargeError(
      `This file is ${(file.size / (1024 * 1024)).toFixed(1)} MB, which is over the ${MAX_FILE_BYTES / (1024 * 1024)} MB limit in this build.`
    );
  }
  return { isPdf, isTxt };
}

/**
 * Core orchestration: given page-separated text (a single "page" for .txt,
 * one entry per PDF page), runs the full local analysis pipeline and
 * returns a typed AnalysisResult. This is the same page-aware logic as the
 * original prototype's runAnalysis(), factored out so it can be unit
 * tested without a DOM, a File object, or a real PDF.
 */
export function analyzePages(
  fileName: string,
  fileSizeBytes: number,
  pageTexts: PageText[],
  isPdf: boolean,
  pdfPageCount: number | null
): AnalysisResult {
  const fullText = pageTexts.map((p) => p.text).join('\n\n');

  if (countWords(fullText) === 0) {
    throw new EmptyContentError(
      isPdf
        ? 'No extractable text was found in this PDF. It may be a scanned/image-only document — OCR is not implemented in this build.'
        : 'No readable text was found in this file.'
    );
  }

  const headings: HeadingInfo[] = [];
  const tables: TableBlock[] = [];
  const sentenceRecords: SentenceRecord[] = [];
  let carryHeading: string | null = null; // most recent heading, carried across pages

  pageTexts.forEach((p) => {
    const hs = extractHeadings(p.text);
    hs.forEach((h) => headings.push({ ...h, pageNumber: p.pageNumber }));

    const tbls = detectTables(p.text);
    tbls.forEach((t) => tables.push({ ...t, pageNumber: p.pageNumber }));

    // Attribute each sentence to the heading *nearest above it*, not just
    // "the first heading anywhere on this page" — the earlier version
    // applied one blanket heading to every sentence on a page, which for a
    // .txt file (always exactly one "page") meant the whole document's
    // citations all pointed at its very first heading regardless of which
    // section a sentence actually came from. Fixed by walking line-by-line,
    // grouping into paragraphs, and re-running splitSentences() (unchanged)
    // per paragraph under the heading active at that point.
    const headingByLine = new Map(hs.map((h) => [h.lineIndex, h.text]));
    const lines = p.text.split(/\r\n|\r|\n/);
    let paragraphLines: string[] = [];
    let headingForParagraph = carryHeading;

    const flushParagraph = () => {
      if (paragraphLines.length === 0) return;
      const sents = splitSentences(paragraphLines.join(' '));
      sents.forEach((s) => sentenceRecords.push({ text: s, pageNumber: p.pageNumber, heading: headingForParagraph }));
      paragraphLines = [];
    };

    lines.forEach((line, lineIndex) => {
      const headingHere = headingByLine.get(lineIndex);
      if (headingHere !== undefined) {
        flushParagraph();
        carryHeading = headingHere;
        headingForParagraph = headingHere;
        return; // the heading line itself isn't body content
      }
      if (line.trim() === '') {
        flushParagraph();
        headingForParagraph = carryHeading;
        return;
      }
      paragraphLines.push(line);
    });
    flushParagraph();
  });

  const stats = {
    fileType: isPdf ? 'PDF document' : 'Plain text file',
    fileSizeBytes,
    pageCount: pdfPageCount,
    wordCount: countWords(fullText),
    charCount: countChars(fullText),
    lineCount: countLines(fullText),
    readingTimeMin: estimateReadingTimeMinutes(countWords(fullText)),
  };

  const languageInfo = detectLanguage(fullText);
  const entities = extractEntities(fullText);
  const summary = summarize(fullText);
  const qaIndex = buildIndex(sentenceRecords.map((r) => r.text));

  return {
    fileName,
    isPdf,
    stats,
    languageInfo,
    headings,
    tables,
    entities,
    summary,
    sentenceRecords,
    qaIndex,
    fullText,
  };
}

/**
 * Full client-side pipeline for a .txt File: read -> analyze.
 * (PDF's equivalent lives in hooks/useFileAnalysis.ts because it needs the
 * dynamically-imported, browser-only lib/pdf.ts.)
 */
export async function analyzeTextFile(file: File): Promise<AnalysisResult> {
  const text = await file.text();
  return analyzePages(file.name, file.size, [{ pageNumber: null, text }], false, null);
}
